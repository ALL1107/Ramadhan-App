const ttsQuestions = {
    easy: [
        { word: "PUASA", clue: "Ibadah wajib di bulan Ramadhan", x: 0, y: 0, dir: "across" },
        { word: "ZAKAT", clue: "Harta yang wajib dikeluarkan untuk fakir miskin", x: 0, y: 2, dir: "across" }
    ],
    normal: [
        { word: "TARAWIH", clue: "Sholat sunnah di malam Ramadhan", x: 0, y: 1, dir: "across" },
        { word: "SAHUR", clue: "Makan sebelum subuh", x: 2, y: 0, dir: "down" }
    ],
    hard: [
        // Tambahkan soal lebih banyak di sini
    ]
};
