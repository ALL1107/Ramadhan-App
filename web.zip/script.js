// --- NAVIGASI ---
function showSection(id) {
    document.querySelectorAll('section').forEach(s => s.classList.remove('active'));
    document.getElementById(id).classList.add('active');
}

// --- JADWAL SHOLAT ---
const CITY = "Kotabaru";
const COUNTRY = "Indonesia";

async function getPrayTime() {
    try {
        const resp = await fetch(`https://api.aladhan.com/v1/timingsByCity?city=${CITY}&country=${COUNTRY}&method=2`);
        const data = await resp.json();
        const timings = data.data.timings;
        displaySholat(timings);
        startCountdown(timings);
    } catch (err) {
        console.error("Gagal ambil jadwal sholat");
    }
}

function displaySholat(times) {
    const list = document.getElementById('sholat-list');
    const displayNames = { 'Fajr': 'Subuh', 'Dhuhr': 'Dzuhur', 'Asr': 'Ashar', 'Maghrib': 'Maghrib', 'Isha': 'Isya' };
    
    list.innerHTML = "";
    for (let key in displayNames) {
        list.innerHTML += `
            <div class="sholat-card">
                <span>${displayNames[key]}</span>
                <b>${times[key]}</b>
            </div>
        `;
    }
}

// Jam Realtime
setInterval(() => {
    document.getElementById('realtime-clock').innerText = new Date().toLocaleTimeString('id-ID');
}, 1000);

// --- LOGIKA GAME (SEDERHANA) ---
let currentGameData = [];

function startGame() {
    const name = document.getElementById('player-name').value;
    if(!name) return alert("Isi nama dulu!");
    
    document.getElementById('game-setup').style.display = 'none';
    document.getElementById('game-play').style.display = 'block';
    
    const diff = document.getElementById('difficulty').value;
    currentGameData = ttsQuestions[diff];
    renderGrid(diff);
}

function renderGrid(diff) {
    const grid = document.getElementById('tts-grid');
    let size = diff === 'easy' ? 5 : (diff === 'normal' ? 8 : 10);
    grid.style.gridTemplateColumns = `repeat(${size}, 35px)`;
    grid.innerHTML = "";

    for (let i = 0; i < size * size; i++) {
        const input = document.createElement('input');
        input.classList.add('grid-cell');
        input.maxLength = 1;
        grid.appendChild(input);
    }
    // Catatan: Logika pemetaan soal ke grid memerlukan algoritma looping yang lebih kompleks
    // Untuk tahap SMK, fokuskan pada pengisian kata yang sudah ditentukan koordinatnya.
}

// Load Jadwal Sholat saat buka web
getPrayTime();
